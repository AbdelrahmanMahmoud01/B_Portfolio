﻿using System;

namespace Core.Entities
{
    public class EntityBase
    {
        public Guid Id { get; set; }
    }
}
